package com.example.HomeSegurity.entity;
import jakarta.persistence.*;
import com.example.HomeSegurity.entity.emun.EstadoAvaluo;

@Entity
@Table(name = "Avaluos")
public class Avaluos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_avaluos")
    private Long id;

    private String Tipo;
    private Double Valor;
    @Enumerated(EnumType.STRING)
    private EstadoAvaluo Estado;

    private String Observaciones;

    @ManyToOne
    @JoinColumn(name = "id_perito")
    private Perito perito;

    @ManyToOne
    @JoinColumn(name = "id_metodologia")
    private Metodologia metodologia;

    @ManyToOne
    @JoinColumn(name = "id_citas")
    private Citas citas;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    public Double getValor() {
        return Valor;
    }

    public void setValor(Double valor) {
        Valor = valor;
    }

    public EstadoAvaluo getEstado() {
        return Estado;
    }

    public void setEstado(EstadoAvaluo estado) {
        Estado = estado;
    }
    
    public String getObservaciones() {
        return Observaciones;
    }

    public void setObservaciones(String observaciones) {
        Observaciones = observaciones;
    }

    public Perito getPerito() {
        return perito;
    }

    public void setPerito(Perito perito) {
        this.perito = perito;
    }

    public Metodologia getMetodologia() {
        return metodologia;
    }
    
    public void setMetodologia(Metodologia metodologia) {
        this.metodologia = metodologia;
    }

    public Citas getCitas() {
        return citas;
    }

    public void setCitas(Citas citas) {
        this.citas = citas;
    }
}
