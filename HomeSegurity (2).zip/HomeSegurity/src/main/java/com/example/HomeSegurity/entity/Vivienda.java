package com.example.HomeSegurity.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "Vivienda")
public class Vivienda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_vivienda")
    private Long id;

    private Double Metros_Cuadrados;
    private Integer Numero_Habitaciones;
    private Integer Numero_Baños;
    private String Estado_Inmueble;
    private String Valor_Propiedad;
    private String Direccion;
    private String Valor_construccion;
    private Double Precio;

    @ManyToOne
    @JoinColumn(name = "id_asesoramiento")
    private Asesoramiento asesoramiento;

    @ManyToOne
    @JoinColumn(name = "id_avaluo")
    private Avaluos avaluo;
    
    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getMetros_Cuadrados() {
        return Metros_Cuadrados;
    }

    public void setMetros_Cuadrados(Double metros_Cuadrados) {
        Metros_Cuadrados = metros_Cuadrados;
    }

    public Integer getNumero_Habitaciones() {
        return Numero_Habitaciones;
    }

    public void setNumero_Habitaciones(Integer numero_Habitaciones) {
        Numero_Habitaciones = numero_Habitaciones;
    }

    public Integer getNumero_Baños() {
        return Numero_Baños;
    }

    public void setNumero_Baños(Integer numero_Baños) {
        Numero_Baños = numero_Baños;
    }

    public String getEstado_Inmueble() {
        return Estado_Inmueble;
    }

    public void setEstado_Inmueble(String estado_Inmueble) {
        Estado_Inmueble = estado_Inmueble;
    }

    public String getValor_Propiedad() {
        return Valor_Propiedad;
    }

    public void setValor_Propiedad(String valor_Propiedad) {
        Valor_Propiedad = valor_Propiedad;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }

    public String getValor_construccion() {
        return Valor_construccion;
    }

    public void setValor_construccion(String valor_construccion) {
        Valor_construccion = valor_construccion;
    }

    public Double getPrecio() {
        return Precio;
    }

    public void setPrecio(Double precio) {
        Precio = precio;
    }

    public Asesoramiento getAsesoramiento() {
        return asesoramiento;
    }

    public void setAsesoramiento(Asesoramiento asesoramiento) {
        this.asesoramiento = asesoramiento;
    }

    public Avaluos getAvaluo() {
        return avaluo;
    }

    public void setAvaluo(Avaluos avaluo) {
        this.avaluo = avaluo;
    }
}
