package com.example.HomeSegurity.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "agente_inmobiliario")
public class AgenteInmobiliario {

    @Id
    private Long idAgente;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id_agente_inmobiliario")
    private Usuario usuario;

    private String numTarjetaProfesional;
    private String zonaEspecialidad;
    private int aniosExperiencia;
    
    @ManyToOne
    @JoinColumn(name = "NIT_inmobiliaria")
    private Inmobiliaria inmobiliaria;

    // Getters and Setters
    public Long getIdAgente() {
        return idAgente;
    }
    public void setIdAgente(Long idAgente) {
        this.idAgente = idAgente;
    }
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    public String getNumTarjetaProfesional() {
        return numTarjetaProfesional;
    }
    public void setNumTarjetaProfesional(String numTarjetaProfesional) {
        this.numTarjetaProfesional = numTarjetaProfesional;
    }
    public String getZonaEspecialidad() {
        return zonaEspecialidad;
    }
    public void setZonaEspecialidad(String zonaEspecialidad) {
        this.zonaEspecialidad = zonaEspecialidad;
    }
    public int getAniosExperiencia() {
        return aniosExperiencia;
    }
    public void setAniosExperiencia(int aniosExperiencia) {
        this.aniosExperiencia = aniosExperiencia;
    }
    public Inmobiliaria getInmobiliaria() {
        return inmobiliaria;
    }
    public void setInmobiliaria(Inmobiliaria inmobiliaria) {
        this.inmobiliaria = inmobiliaria;
    }
}
