package com.example.HomeSegurity.entity.emun;

public enum EstadoUsuario {
    ACTIVO,
    INACTIVO
}
