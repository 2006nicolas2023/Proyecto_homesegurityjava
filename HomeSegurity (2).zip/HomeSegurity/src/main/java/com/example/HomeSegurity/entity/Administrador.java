package com.example.HomeSegurity.entity;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "administrador")
public class Administrador {

    @Id
    private Long idAdministrador;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id_administrador")
    private Usuario usuario;

    private int aniosExperiencia;
    private LocalDate fechaIngreso;

    // Getters and Setters
    public Long getIdAdministrador() {
        return idAdministrador;
    }
    public void setIdAdministrador(Long idAdministrador) {
        this.idAdministrador = idAdministrador;
    }
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    public int getAniosExperiencia() {
        return aniosExperiencia;
    }
    public void setAniosExperiencia(int aniosExperiencia) {
        this.aniosExperiencia = aniosExperiencia;
    }
    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }
    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }


}
