package com.example.HomeSegurity.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.HomeSegurity.entity.Cargo;

public interface CargoRepository extends JpaRepository<Cargo, Long> {

    Cargo findByTipoCargo(String tipoCargo);

    Cargo findByUsuarioIdUsuario(Long idUsuario);
}