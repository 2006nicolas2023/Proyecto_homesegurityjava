package com.example.HomeSegurity.entity.emun;

public enum EstadoAvaluo {
    PENDIENTE,
    EN_PROCESO,
    APROBADO,
    RECHAZADO
}
