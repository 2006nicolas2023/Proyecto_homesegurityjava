package com.example.HomeSegurity.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "Metodologia")
public class Metodologia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_metodologia")
    private Long id;

    private String Nom_metodologia;
    private String Descripcion;
    private String Objetivos;
    private String Fases_proceso;
    private String Beneficios;
    private String Recomendaciones;

    // Getters and Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getNom_metodologia() {
        return Nom_metodologia;
    }
    public void setNom_metodologia(String nom_metodologia) {
        Nom_metodologia = nom_metodologia;
    }
    public String getDescripcion() {
        return Descripcion;
    }
    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }
    public String getObjetivos() {
        return Objetivos;
    }
    public void setObjetivos(String objetivos) {
        Objetivos = objetivos;
    }
    public String getFases_proceso() {
        return Fases_proceso;
    }
    public void setFases_proceso(String fases_proceso) {
        Fases_proceso = fases_proceso;
    }
    public String getBeneficios() {
        return Beneficios;
    }
    public void setBeneficios(String beneficios) {
        Beneficios = beneficios;
    }
    public String getRecomendaciones() {
        return Recomendaciones;
    }
    public void setRecomendaciones(String recomendaciones) {
        Recomendaciones = recomendaciones;
    }
}
