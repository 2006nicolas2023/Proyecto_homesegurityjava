package com.example.HomeSegurity.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "Reporte_Venta")
public class ReporteVenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reporte_venta")
    private Long id;

    private Double Valor_Venta;
    private Double Gasto_Administracion;
    private Double Gastos_Seguro;
    private Double Valor_Neto;

    @ManyToOne
    @JoinColumn(name = "id_vivienda")
    private Vivienda vivienda;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getValor_Venta() {
        return Valor_Venta;
    }

    public void setValor_Venta(Double valor_Venta) {
        Valor_Venta = valor_Venta;
    }

    public Double getGasto_Administracion() {
        return Gasto_Administracion;
    }

    public void setGasto_Administracion(Double gasto_Administracion) {
        Gasto_Administracion = gasto_Administracion;
    }

    public Double getGastos_Seguro() {
        return Gastos_Seguro;
    }

    public void setGastos_Seguro(Double gastos_Seguro) {
        Gastos_Seguro = gastos_Seguro;
    }

    public Double getValor_Neto() {
        return Valor_Neto;
    }

    public void setValor_Neto(Double valor_Neto) {
        Valor_Neto = valor_Neto;
    }

    public Vivienda getVivienda() {
        return vivienda;
    }

    public void setVivienda(Vivienda vivienda) {
        this.vivienda = vivienda;
    }
}
