package com.example.HomeSegurity.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "perito")
public class Perito {

    @Id
    private Long idPerito;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id_perito")
    private Usuario usuario;

    private String registroRAA;
    private String categoriaEspecializacion;
    private int aniosExperiencia;
    private String direccion;

    // Getters and Setters
    public Long getIdPerito() {
        return idPerito;
    }
    public void setIdPerito(Long idPerito) {
        this.idPerito = idPerito;
    }
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    public String getRegistroRAA() {
        return registroRAA;
    }
    public void setRegistroRAA(String registroRAA) {
        this.registroRAA = registroRAA;
    }
    public String getCategoriaEspecializacion() {
        return categoriaEspecializacion;
    }
    public void setCategoriaEspecializacion(String categoriaEspecializacion) {
        this.categoriaEspecializacion = categoriaEspecializacion;
    }
    public int getAniosExperiencia() {
        return aniosExperiencia;
    }
    public void setAniosExperiencia(int aniosExperiencia) {
        this.aniosExperiencia = aniosExperiencia;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
