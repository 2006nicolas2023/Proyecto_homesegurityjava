package com.example.HomeSegurity.entity;
import jakarta.persistence.*;
import com.example.HomeSegurity.entity.emun.EstadoUsuario;

@Entity
@Table(name = "usuario")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idUsuario;

    private String primerNombre;
    private String primerApellido;
    private String telefono;
    private int edad;
    private String numDocumento;
    private String correo;
    private String contraseña;

    @Enumerated(EnumType.STRING)
    private EstadoUsuario estado;

    @OneToOne(mappedBy = "usuario", cascade = CascadeType.ALL)
    private Cargo cargo;

    // Getters and Setters
    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getPrimerNombre() {
        return primerNombre;
    }

    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNumDocumento() {
        return numDocumento;
    }

    public void setNumDocumento(String numDocumento) {
        this.numDocumento = numDocumento;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public boolean isEstadoCuenta() {
        return estado == EstadoUsuario.ACTIVO;
    }

    public void setEstadoCuenta(boolean estadoCuenta) {
        this.estado = estadoCuenta ? EstadoUsuario.ACTIVO : EstadoUsuario.INACTIVO;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

}
