package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.Asesoramiento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AsesoramientoRepository extends JpaRepository<Asesoramiento, Long> {
}
