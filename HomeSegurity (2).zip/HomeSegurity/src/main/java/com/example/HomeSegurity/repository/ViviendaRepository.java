package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.Vivienda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ViviendaRepository extends JpaRepository<Vivienda, Long> {
}
