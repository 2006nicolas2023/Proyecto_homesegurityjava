package com.example.HomeSegurity.entity;
import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "Inmobiliaria")
public class Inmobiliaria {

    @Id
    @Column(name = "NIT_inmobiliaria")
    private Long nitInmobiliaria;

    private String Nombre;
    private String Direccion;
    private String Telefono;
    private String Fecha_Fundacion;
    private String Email_contacto;
    private String Horario_Atencion;

    @OneToMany(mappedBy = "inmobiliaria")
    private List<AgenteInmobiliario> agentes;

    // Getters and Setters
    public Long getNitInmobiliaria() {
        return nitInmobiliaria;
    }

    public void setNitInmobiliaria(Long nitInmobiliaria) {
        this.nitInmobiliaria = nitInmobiliaria;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        Direccion = direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }

    public String getFecha_Fundacion() {
        return Fecha_Fundacion;
    }

    public void setFecha_Fundacion(String fecha_Fundacion) {
        Fecha_Fundacion = fecha_Fundacion;
    }

    public String getEmail_contacto() {
        return Email_contacto;
    }

    public void setEmail_contacto(String email_contacto) {
        Email_contacto = email_contacto;
    }

    public String getHorario_Atencion() {
        return Horario_Atencion;
    }

    public void setHorario_Atencion(String horario_Atencion) {
        Horario_Atencion = horario_Atencion;
    }

    public List<AgenteInmobiliario> getAgentes() {
        return agentes;
    }

    public void setAgentes(List<AgenteInmobiliario> agentes) {
        this.agentes = agentes;
    }

}

