package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.Citas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CitasRepository extends JpaRepository<Citas, Long> {
}