package com.example.HomeSegurity.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.HomeSegurity.entity.Administrador;

public interface AdministradorRepository extends JpaRepository<Administrador, Long> {

}