package com.example.HomeSegurity.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "Reporte_Arriendo")
public class ReporteArriendo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reporte_arriendo")
    private Long id;

    private Double Valor_Arriendo;
    private Double Gasto_Administracion;
    private Double Gastos_Poliza;
    private Double Valor_Propiedad;

    @ManyToOne
    @JoinColumn(name = "id_vivienda")
    private Vivienda vivienda;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getValor_Arriendo() {
        return Valor_Arriendo;
    }

    public void setValor_Arriendo(Double valor_Arriendo) {
        Valor_Arriendo = valor_Arriendo;
    }

    public Double getGasto_Administracion() {
        return Gasto_Administracion;
    }

    public void setGasto_Administracion(Double gasto_Administracion) {
        Gasto_Administracion = gasto_Administracion;
    }

    public Double getGastos_Poliza() {
        return Gastos_Poliza;
    }

    public void setGastos_Poliza(Double gastos_Poliza) {
        Gastos_Poliza = gastos_Poliza;
    }

    public Double getValor_Propiedad() {
        return Valor_Propiedad;
    }

    public void setValor_Propiedad(Double valor_Propiedad) {
        Valor_Propiedad = valor_Propiedad;
    }

    public Vivienda getVivienda() {
        return vivienda;
    }

    public void setVivienda(Vivienda vivienda) {
        this.vivienda = vivienda;
    }
}