package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.Metodologia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetodologiaRepository extends JpaRepository<Metodologia, Long> {
}
