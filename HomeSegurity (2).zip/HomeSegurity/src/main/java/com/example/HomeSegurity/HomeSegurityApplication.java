package com.example.HomeSegurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeSegurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeSegurityApplication.class, args);
	}

}
