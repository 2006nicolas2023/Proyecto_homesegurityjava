package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.ReporteVenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReporteVentaRepository extends JpaRepository<ReporteVenta, Long> {
}
