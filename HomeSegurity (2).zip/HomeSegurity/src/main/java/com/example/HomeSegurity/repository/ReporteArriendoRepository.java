package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.ReporteArriendo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReporteArriendoRepository extends JpaRepository<ReporteArriendo, Long> {
}
