package com.example.HomeSegurity.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.HomeSegurity.entity.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Buscar por correo (para login)
    Usuario findByCorreo(String correo);

}