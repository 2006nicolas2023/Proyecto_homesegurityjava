package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.Avaluos;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AvaluosRepository extends JpaRepository<Avaluos, Long> {
}
