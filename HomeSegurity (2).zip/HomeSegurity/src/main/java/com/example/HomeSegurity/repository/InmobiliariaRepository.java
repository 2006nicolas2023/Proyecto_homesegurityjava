package com.example.HomeSegurity.repository;

import com.example.HomeSegurity.entity.Inmobiliaria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InmobiliariaRepository extends JpaRepository<Inmobiliaria, Long> {
}
