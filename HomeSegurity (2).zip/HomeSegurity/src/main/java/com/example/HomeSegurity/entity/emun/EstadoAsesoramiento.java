package com.example.HomeSegurity.entity.emun;

public enum EstadoAsesoramiento {
    EN_PROCESO,
    CONFIRMADA,
    REPROGRAMADA,
    CANCELADA
}
