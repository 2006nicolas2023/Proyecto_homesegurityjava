package com.example.HomeSegurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeSegurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
